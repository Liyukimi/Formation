package com.objis.spring.demodatabase.presentation;

public final class PageFolderMapping {
	    private PageFolderMapping(){}
	    public static final String EMPLOYES_PATH = "/employes/";

	
}
